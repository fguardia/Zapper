package com.zapper.iptv.data

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** Streaming XMLTV parser that keeps only the channels and time window we need. */
object XmltvParser {

    private val fmtTz = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)
    private val fmtUtc = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    fun parseTime(s: String?): Long {
        if (s.isNullOrBlank()) return 0
        val t = s.trim()
        return try {
            if (t.length > 14) {
                val norm = if (t[14] != ' ') t.substring(0, 14) + " " + t.substring(14) else t
                fmtTz.parse(norm)?.time ?: 0
            } else {
                fmtUtc.parse(t.take(14))?.time ?: 0
            }
        } catch (e: Exception) {
            0
        }
    }

    /** @param wanted lower-case channel ids */
    fun parse(input: InputStream, wanted: Set<String>, from: Long, to: Long): Map<String, List<Programme>> {
        val result = HashMap<String, MutableList<Programme>>()
        try {
            val parser = Xml.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(input, null)
            var ev = parser.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && parser.name == "programme") {
                    val ch = parser.getAttributeValue(null, "channel")?.lowercase()
                    if (ch != null && ch in wanted) {
                        val start = parseTime(parser.getAttributeValue(null, "start"))
                        val stop = parseTime(parser.getAttributeValue(null, "stop"))
                        val depth = parser.depth
                        var title = ""
                        var desc = ""
                        while (true) {
                            ev = parser.next()
                            if (ev == XmlPullParser.END_DOCUMENT) break
                            if (ev == XmlPullParser.END_TAG && parser.depth == depth) break
                            if (ev == XmlPullParser.START_TAG) {
                                when (parser.name) {
                                    "title" -> if (title.isEmpty()) title = parser.nextText().trim()
                                    "desc" -> if (desc.isEmpty()) desc = parser.nextText().trim()
                                }
                            }
                        }
                        if (stop > from && start < to && stop > start) {
                            result.getOrPut(ch) { ArrayList() }.add(Programme(start, stop, title, desc))
                        }
                        if (ev == XmlPullParser.END_DOCUMENT) break
                    }
                }
                ev = parser.next()
            }
        } catch (e: Exception) {
            // Truncated or malformed guide: keep whatever was parsed.
        }
        result.values.forEach { list -> list.sortBy { it.start } }
        return result
    }
}
