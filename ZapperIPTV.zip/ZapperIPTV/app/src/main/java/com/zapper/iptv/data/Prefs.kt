package com.zapper.iptv.data

import android.content.Context
import org.json.JSONArray

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("zapper", Context.MODE_PRIVATE)

    fun playlists(): List<Playlist> {
        val arr = try { JSONArray(sp.getString("playlists", "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let { o -> Playlist.fromJson(o) } }
    }

    private fun savePlaylists(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp.edit().putString("playlists", arr.toString()).apply()
    }

    fun addPlaylist(p: Playlist) = savePlaylists(playlists().filter { it.id != p.id } + p)

    fun removePlaylist(id: String) {
        savePlaylists(playlists().filter { it.id != id })
        sp.edit().remove("fav_$id").remove("last_$id").apply()
        if (activeId == id) activeId = null
    }

    var activeId: String?
        get() = sp.getString("active", null)
        set(v) {
            sp.edit().putString("active", v).apply()
        }

    fun active(): Playlist? {
        val all = playlists()
        return all.firstOrNull { it.id == activeId } ?: all.firstOrNull()
    }

    fun favorites(pid: String): MutableSet<String> =
        HashSet(sp.getStringSet("fav_$pid", emptySet()) ?: emptySet())

    fun saveFavorites(pid: String, set: Set<String>) {
        sp.edit().putStringSet("fav_$pid", HashSet(set)).apply()
    }

    fun lastChannel(pid: String): String? = sp.getString("last_$pid", null)

    fun setLastChannel(pid: String, channelId: String) {
        sp.edit().putString("last_$pid", channelId).apply()
    }
}
