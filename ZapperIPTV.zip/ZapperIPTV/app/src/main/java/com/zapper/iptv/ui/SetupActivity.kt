package com.zapper.iptv.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.zapper.iptv.R
import com.zapper.iptv.data.Net
import com.zapper.iptv.data.Playlist
import com.zapper.iptv.data.Prefs
import com.zapper.iptv.data.XtreamApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class SetupActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var playlistSection: View
    private lateinit var container: LinearLayout
    private lateinit var rbXtream: RadioButton
    private lateinit var xtreamGroup: View
    private lateinit var etName: EditText
    private lateinit var etServer: EditText
    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var etM3u: EditText
    private lateinit var etEpg: EditText
    private lateinit var etUa: EditText
    private lateinit var cbHls: CheckBox
    private lateinit var btnSave: Button
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)
        prefs = Prefs(this)

        playlistSection = findViewById(R.id.playlistSection)
        container = findViewById(R.id.playlistContainer)
        rbXtream = findViewById(R.id.rbXtream)
        xtreamGroup = findViewById(R.id.xtreamGroup)
        etName = findViewById(R.id.etName)
        etServer = findViewById(R.id.etServer)
        etUser = findViewById(R.id.etUser)
        etPass = findViewById(R.id.etPass)
        etM3u = findViewById(R.id.etM3u)
        etEpg = findViewById(R.id.etEpg)
        etUa = findViewById(R.id.etUa)
        cbHls = findViewById(R.id.cbHls)
        btnSave = findViewById(R.id.btnSave)
        status = findViewById(R.id.status)

        findViewById<RadioGroup>(R.id.typeGroup).setOnCheckedChangeListener { _, _ -> updateMode() }
        btnSave.setOnClickListener { save() }
        updateMode()
        renderPlaylists()
    }

    private fun updateMode() {
        val x = rbXtream.isChecked
        xtreamGroup.visibility = if (x) View.VISIBLE else View.GONE
        etM3u.visibility = if (x) View.GONE else View.VISIBLE
    }

    private fun renderPlaylists() {
        container.removeAllViews()
        val list = prefs.playlists()
        playlistSection.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        val activeId = prefs.active()?.id
        val dp = resources.displayMetrics.density
        list.forEach { p ->
            val b = Button(this, null, 0, R.style.TvButton)
            val kind = if (p.type == Playlist.XTREAM) "Xtream" else "M3U"
            b.text = (if (p.id == activeId) "▶  " else "") + "${p.name}   ·   $kind"
            b.isAllCaps = false
            b.setOnClickListener {
                prefs.activeId = p.id
                openMain()
            }
            b.setOnLongClickListener {
                confirmDelete(p)
                true
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = (8 * dp).toInt()
            container.addView(b, lp)
        }
        if (list.isNotEmpty()) container.getChildAt(0).requestFocus() else etName.requestFocus()
    }

    private fun confirmDelete(p: Playlist) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.delete_playlist, p.name))
            .setPositiveButton(R.string.delete) { _, _ ->
                prefs.removePlaylist(p.id)
                renderPlaylists()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun save() {
        val isX = rbXtream.isChecked
        val server = etServer.text.toString().trim()
        val user = etUser.text.toString().trim()
        val pass = etPass.text.toString().trim()
        val m3u = etM3u.text.toString().trim()
        if (isX && (server.isEmpty() || user.isEmpty() || pass.isEmpty())) {
            status.setText(R.string.fill_xtream); return
        }
        if (!isX && m3u.isEmpty()) {
            status.setText(R.string.fill_m3u); return
        }
        val p = Playlist(
            id = UUID.randomUUID().toString(),
            name = etName.text.toString().trim().ifEmpty { if (isX) "Xtream" else "M3U" },
            type = if (isX) Playlist.XTREAM else Playlist.M3U,
            server = server,
            username = user,
            password = pass,
            m3uUrl = m3u,
            epgUrl = etEpg.text.toString().trim(),
            useHls = cbHls.isChecked,
            userAgent = etUa.text.toString().trim().ifEmpty { Net.DEFAULT_UA }
        )

        btnSave.isEnabled = false
        status.setText(R.string.checking)
        lifecycleScope.launch {
            val err: String? = withContext(Dispatchers.IO) {
                try {
                    if (isX) XtreamApi(p).checkLogin()
                    else {
                        Net.open(p.m3uUrl, p.userAgent).close()
                        null
                    }
                } catch (e: Exception) {
                    e.message ?: e.javaClass.simpleName
                }
            }
            btnSave.isEnabled = true
            if (err != null) {
                status.text = getString(R.string.error_fmt, err)
                return@launch
            }
            status.text = ""
            prefs.addPlaylist(p)
            prefs.activeId = p.id
            openMain()
        }
    }

    private fun openMain() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
        finish()
    }
}
