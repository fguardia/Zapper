package com.zapper.iptv.ui

import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.zapper.iptv.R
import com.zapper.iptv.data.Episode
import com.zapper.iptv.data.ResumeStore
import com.zapper.iptv.data.VodItem

class PosterAdapter(
    private val posterHeightPx: Int,
    private val resume: ResumeStore,
    private val onClicked: (VodItem) -> Unit
) : RecyclerView.Adapter<PosterAdapter.VH>() {

    var items: List<VodItem> = emptyList()
        set(v) {
            field = v
            notifyDataSetChanged()
        }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image: ImageView = v.findViewById(R.id.posterImage)
        val name: TextView = v.findViewById(R.id.posterName)
        val rating: TextView = v.findViewById(R.id.posterRating)
        val progress: ProgressBar = v.findViewById(R.id.posterProgress)
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_poster, parent, false)
        val h = VH(v)
        h.image.layoutParams = h.image.layoutParams.apply { height = posterHeightPx }
        v.setOnClickListener {
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClicked(items[pos])
        }
        v.setOnFocusChangeListener { view, hasFocus ->
            val s = if (hasFocus) 1.06f else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(120).start()
            view.translationZ = if (hasFocus) 8f else 0f
        }
        return h
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.name.text = item.name
        Glide.with(h.image).load(item.poster)
            .placeholder(ColorDrawable(0xFF1A1E28.toInt()))
            .error(ColorDrawable(0xFF1A1E28.toInt()))
            .centerCrop()
            .into(h.image)
        val rating = item.rating?.toDoubleOrNull()
        if (rating != null && rating > 0) {
            h.rating.text = "★ " + (if (rating > 10) String.format("%.0f", rating) else String.format("%.1f", rating))
            h.rating.visibility = View.VISIBLE
        } else {
            h.rating.visibility = View.GONE
        }
        val pos = resume.position(item.key)
        val dur = resume.duration(item.key)
        if (pos > 0 && dur > 0) {
            h.progress.progress = ((pos * 1000) / dur).toInt().coerceIn(0, 1000)
            h.progress.visibility = View.VISIBLE
        } else {
            h.progress.visibility = View.GONE
        }
    }
}

class EpisodeAdapter(
    private val resume: ResumeStore,
    private val onClicked: (Episode) -> Unit
) : RecyclerView.Adapter<EpisodeAdapter.VH>() {

    var items: List<Episode> = emptyList()
        set(v) {
            field = v
            notifyDataSetChanged()
        }

    fun refresh() {
        if (items.isNotEmpty()) notifyItemRangeChanged(0, items.size, "state")
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image: ImageView = v.findViewById(R.id.epImage)
        val title: TextView = v.findViewById(R.id.epTitle)
        val plot: TextView = v.findViewById(R.id.epPlot)
        val progress: ProgressBar = v.findViewById(R.id.epProgress)
        val watched: TextView = v.findViewById(R.id.epWatched)
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_episode, parent, false)
        val h = VH(v)
        v.setOnClickListener {
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClicked(items[pos])
        }
        return h
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val ep = items[position]
        Glide.with(h.image).load(ep.image)
            .placeholder(ColorDrawable(0xFF1A1E28.toInt()))
            .error(ColorDrawable(0xFF1A1E28.toInt()))
            .centerCrop()
            .into(h.image)
        bindState(h, ep)
    }

    override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isEmpty()) onBindViewHolder(h, position) else bindState(h, items[position])
    }

    private fun bindState(h: VH, ep: Episode) {
        val ctx = h.itemView.context
        val name = ep.title.ifBlank { ctx.getString(R.string.season_fmt, ep.season) }
        h.title.text = ctx.getString(R.string.episode_fmt, ep.num, name)
        val extra = if (ep.duration.isNotBlank()) "${ep.duration}  ·  " else ""
        h.plot.text = extra + ep.plot
        h.plot.visibility = if (h.plot.text.isNullOrBlank()) View.GONE else View.VISIBLE
        val pos = resume.position(ep.key)
        val dur = resume.duration(ep.key)
        if (pos > 0 && dur > 0) {
            h.progress.progress = ((pos * 1000) / dur).toInt().coerceIn(0, 1000)
            h.progress.visibility = View.VISIBLE
        } else {
            h.progress.visibility = View.GONE
        }
        h.watched.visibility = if (resume.isWatched(ep.key)) View.VISIBLE else View.GONE
    }
}
