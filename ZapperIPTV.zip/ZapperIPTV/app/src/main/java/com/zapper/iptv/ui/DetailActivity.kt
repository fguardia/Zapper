package com.zapper.iptv.ui

import android.content.Context
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.zapper.iptv.R
import com.zapper.iptv.data.Episode
import com.zapper.iptv.data.Playlist
import com.zapper.iptv.data.Prefs
import com.zapper.iptv.data.ResumeStore
import com.zapper.iptv.data.VodDetails
import com.zapper.iptv.data.VodItem
import com.zapper.iptv.data.VodRepo
import com.zapper.iptv.data.formatMs
import kotlinx.coroutines.launch

/** Movie or series page: poster, info, play/resume, seasons and episodes. */
class DetailActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_KIND = "kind"
        private const val EXTRA_ID = "id"

        fun newIntent(ctx: Context, kind: String, id: String): Intent =
            Intent(ctx, DetailActivity::class.java).putExtra(EXTRA_KIND, kind).putExtra(EXTRA_ID, id)
    }

    private lateinit var item: VodItem
    private lateinit var playlist: Playlist
    private lateinit var resume: ResumeStore
    private var details: VodDetails? = null

    private lateinit var backdrop: ImageView
    private lateinit var poster: ImageView
    private lateinit var title: TextView
    private lateinit var meta: TextView
    private lateinit var plot: TextView
    private lateinit var credits: TextView
    private lateinit var btnPlay: Button
    private lateinit var btnRestart: Button
    private lateinit var loadingView: View
    private lateinit var seasonScroll: View
    private lateinit var seasonRow: LinearLayout
    private lateinit var episodeList: RecyclerView
    private lateinit var episodeAdapter: EpisodeAdapter

    private var currentSeason = -1
    private val seasonButtons = HashMap<Int, Button>()

    /** Series from Xtream have episodes; movies and M3U items play directly. */
    private val isSeries: Boolean get() = item.url == null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val kind = intent.getStringExtra(EXTRA_KIND) ?: VodItem.MOVIE
        val id = intent.getStringExtra(EXTRA_ID) ?: ""
        val p = Prefs(this).active()
        val found = VodRepo.find(kind, id)
        if (p == null || found == null) {
            finish()
            return
        }
        playlist = p
        item = found
        resume = ResumeStore(this, p.id)
        setContentView(R.layout.activity_detail)

        backdrop = findViewById(R.id.backdrop)
        poster = findViewById(R.id.detailPoster)
        title = findViewById(R.id.detailTitle)
        meta = findViewById(R.id.detailMeta)
        plot = findViewById(R.id.detailPlot)
        credits = findViewById(R.id.detailCredits)
        btnPlay = findViewById(R.id.btnPlay)
        btnRestart = findViewById(R.id.btnRestart)
        loadingView = findViewById(R.id.detailLoading)
        seasonScroll = findViewById(R.id.seasonScroll)
        seasonRow = findViewById(R.id.seasonRow)
        episodeList = findViewById(R.id.episodeList)

        episodeAdapter = EpisodeAdapter(resume) { ep -> playEpisode(ep, startOver = false) }
        episodeList.layoutManager = LinearLayoutManager(this)
        episodeList.itemAnimator = null
        episodeList.adapter = episodeAdapter

        title.text = item.name
        loadImage(poster, item.poster)
        loadImage(backdrop, item.poster)
        btnPlay.setOnClickListener { onPlay(startOver = false) }
        btnRestart.setOnClickListener { onPlay(startOver = true) }
        btnPlay.isEnabled = !isSeries
        btnPlay.requestFocus()
        updateButtons()

        lifecycleScope.launch {
            val d = try {
                VodRepo.details(playlist, item)
            } catch (e: Exception) {
                Toast.makeText(this@DetailActivity, R.string.details_failed, Toast.LENGTH_SHORT).show()
                VodDetails(title = item.name, poster = item.poster)
            }
            details = d
            loadingView.visibility = View.GONE
            bindDetails(d)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::btnPlay.isInitialized) {
            updateButtons()
            episodeAdapter.refresh()
        }
    }

    private fun loadImage(view: ImageView, url: String?) {
        Glide.with(view).load(url)
            .placeholder(ColorDrawable(0xFF1A1E28.toInt()))
            .error(ColorDrawable(0xFF1A1E28.toInt()))
            .centerCrop()
            .into(view)
    }

    private fun bindDetails(d: VodDetails) {
        if (d.poster != null && d.poster != item.poster) loadImage(poster, d.poster)
        loadImage(backdrop, d.backdrop ?: d.poster ?: item.poster)

        val parts = ArrayList<String>()
        if (d.year.isNotBlank()) parts.add(d.year)
        if (d.genre.isNotBlank()) parts.add(d.genre)
        if (d.duration.isNotBlank()) parts.add(d.duration)
        d.rating.toDoubleOrNull()?.takeIf { it > 0 }?.let {
            parts.add("★ " + if (it > 10) String.format("%.0f", it) else String.format("%.1f", it))
        }
        if (isSeries && d.seasons.isNotEmpty()) {
            parts.add(resources.getQuantityString(R.plurals.seasons_count, d.seasons.size, d.seasons.size))
        }
        meta.text = parts.joinToString("   ·   ")
        plot.text = d.plot
        plot.visibility = if (d.plot.isBlank()) View.GONE else View.VISIBLE
        val c = ArrayList<String>()
        if (d.director.isNotBlank()) c.add(getString(R.string.director_fmt, d.director))
        if (d.cast.isNotBlank()) c.add(getString(R.string.cast_fmt, d.cast))
        credits.text = c.joinToString("\n")
        credits.visibility = if (c.isEmpty()) View.GONE else View.VISIBLE

        if (isSeries) buildSeasons(d)
        updateButtons()
    }

    private fun buildSeasons(d: VodDetails) {
        seasonRow.removeAllViews()
        seasonButtons.clear()
        if (d.seasons.isEmpty()) {
            Toast.makeText(this, R.string.nothing_here, Toast.LENGTH_SHORT).show()
            return
        }
        val dp = resources.displayMetrics.density
        d.seasons.keys.forEach { s ->
            val b = Button(this, null, 0, R.style.TvButton)
            b.text = getString(R.string.season_fmt, s)
            b.isAllCaps = false
            b.setOnClickListener { showSeason(s) }
            b.setOnFocusChangeListener { _, has -> if (has) showSeason(s) }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = (8 * dp).toInt()
            seasonRow.addView(b, lp)
            seasonButtons[s] = b
        }
        seasonScroll.visibility = View.VISIBLE
        episodeList.visibility = View.VISIBLE
        val start = nextEpisode()?.season ?: d.seasons.keys.first()
        showSeason(start)
    }

    private fun showSeason(s: Int) {
        if (s == currentSeason) return
        currentSeason = s
        seasonButtons.forEach { (k, b) -> b.isActivated = k == s; b.alpha = if (k == s) 1f else 0.7f }
        episodeAdapter.items = details?.seasons?.get(s) ?: emptyList()
        episodeList.scrollToPosition(0)
    }

    private fun allEpisodes(): List<Episode> =
        details?.seasons?.values?.flatten() ?: emptyList()

    /** Episode in progress, else first unwatched, else the first one. */
    private fun nextEpisode(): Episode? {
        val all = allEpisodes()
        if (all.isEmpty()) return null
        all.firstOrNull { resume.position(it.key) > 0 }?.let { return it }
        val lastWatched = all.indexOfLast { resume.isWatched(it.key) }
        return all.getOrNull(lastWatched + 1) ?: all.first()
    }

    private fun updateButtons() {
        if (isSeries) {
            val ep = nextEpisode()
            if (ep == null) {
                btnPlay.isEnabled = false
                btnPlay.setText(R.string.play)
                btnRestart.visibility = View.GONE
                return
            }
            btnPlay.isEnabled = true
            val inProgress = resume.position(ep.key) > 0
            btnPlay.text = getString(if (inProgress) R.string.continue_fmt else R.string.play_ep_fmt, ep.season, ep.num)
            btnRestart.visibility = if (inProgress) View.VISIBLE else View.GONE
        } else {
            val pos = resume.position(item.key)
            btnPlay.text = if (pos > 0) getString(R.string.resume_fmt, formatMs(pos)) else getString(R.string.play)
            btnRestart.visibility = if (pos > 0) View.VISIBLE else View.GONE
        }
    }

    private fun onPlay(startOver: Boolean) {
        if (isSeries) {
            nextEpisode()?.let { playEpisode(it, startOver) }
        } else {
            val url = item.url ?: return
            startActivity(
                VodPlayerActivity.newIntent(
                    this,
                    arrayListOf(url),
                    arrayListOf(item.name),
                    arrayListOf(item.key),
                    0,
                    startOver,
                    null
                )
            )
        }
    }

    private fun playEpisode(ep: Episode, startOver: Boolean) {
        val all = allEpisodes()
        val index = all.indexOfFirst { it.id == ep.id }.coerceAtLeast(0)
        val titles = all.map { e ->
            val name = e.title.ifBlank { item.name }
            "S${e.season} E${e.num}  ·  $name"
        }
        startActivity(
            VodPlayerActivity.newIntent(
                this,
                ArrayList(all.map { it.url }),
                ArrayList(titles),
                ArrayList(all.map { it.key }),
                index,
                startOver,
                item.id
            )
        )
    }
}
