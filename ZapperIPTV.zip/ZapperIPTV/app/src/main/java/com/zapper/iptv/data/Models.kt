package com.zapper.iptv.data

import org.json.JSONObject

data class Playlist(
    val id: String,
    val name: String,
    val type: String,
    val server: String = "",
    val username: String = "",
    val password: String = "",
    val m3uUrl: String = "",
    val epgUrl: String = "",
    val useHls: Boolean = false,
    val userAgent: String = Net.DEFAULT_UA
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("type", type)
        put("server", server)
        put("username", username)
        put("password", password)
        put("m3uUrl", m3uUrl)
        put("epgUrl", epgUrl)
        put("useHls", useHls)
        put("userAgent", userAgent)
    }

    companion object {
        const val XTREAM = "xtream"
        const val M3U = "m3u"

        fun fromJson(o: JSONObject) = Playlist(
            id = o.optString("id"),
            name = o.optString("name"),
            type = o.optString("type", XTREAM),
            server = o.optString("server"),
            username = o.optString("username"),
            password = o.optString("password"),
            m3uUrl = o.optString("m3uUrl"),
            epgUrl = o.optString("epgUrl"),
            useHls = o.optBoolean("useHls", false),
            userAgent = o.optString("userAgent", Net.DEFAULT_UA).ifBlank { Net.DEFAULT_UA }
        )
    }
}

data class Category(val id: String, val name: String)

data class Channel(
    val id: String,
    val num: Int,
    val name: String,
    val logo: String?,
    val url: String,
    val categoryId: String,
    val epgId: String?,
    val streamId: String?
)

data class Programme(val start: Long, val end: Long, val title: String, val desc: String)

/** Returns (programme on now, programme after it). List must be sorted by start. */
fun nowNext(list: List<Programme>?, now: Long = System.currentTimeMillis()): Pair<Programme?, Programme?> {
    if (list.isNullOrEmpty()) return null to null
    val i = list.indexOfFirst { now >= it.start && now < it.end }
    return if (i >= 0) list[i] to list.getOrNull(i + 1)
    else null to list.firstOrNull { it.start > now }
}

/** org.json returns the text "null" for JSON nulls; treat that as empty. */
fun JSONObject.str(key: String): String {
    val v = optString(key, "")
    return if (v == "null") "" else v
}
