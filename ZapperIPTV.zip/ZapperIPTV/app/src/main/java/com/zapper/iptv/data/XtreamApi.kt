package com.zapper.iptv.data

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** Minimal Xtream Codes "player_api.php" client (live TV only). */
class XtreamApi(private val p: Playlist) {

    val base: String = p.server.trim().trimEnd('/').let {
        if (it.startsWith("http://", true) || it.startsWith("https://", true)) it else "http://$it"
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun api(action: String? = null, extra: String = ""): String {
        val sb = StringBuilder("$base/player_api.php?username=${enc(p.username)}&password=${enc(p.password)}")
        if (action != null) sb.append("&action=").append(action)
        sb.append(extra)
        return Net.getString(sb.toString(), p.userAgent)
    }

    /** Returns null when login is OK, otherwise a readable error. */
    fun checkLogin(): String? {
        val txt = api()
        val o = try { JSONObject(txt) } catch (e: Exception) { return "The server did not return a valid Xtream response" }
        val ui = o.optJSONObject("user_info") ?: return "The server did not return account info"
        if (ui.optInt("auth", 0) != 1) return "Wrong username or password"
        val status = ui.str("status")
        if (status.isNotEmpty() && !status.equals("Active", true)) return "Account status: $status"
        return null
    }

    fun categories(): List<Category> {
        val arr = JSONArray(api("get_live_categories"))
        val out = ArrayList<Category>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Category(o.str("category_id"), o.str("category_name").trim()))
        }
        return out
    }

    fun channels(): List<Channel> {
        val arr = JSONArray(api("get_live_streams"))
        val ext = if (p.useHls) "m3u8" else "ts"
        val out = ArrayList<Channel>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val sid = o.str("stream_id")
            if (sid.isEmpty()) continue
            val num = o.optInt("num", 0).let { if (it > 0) it else i + 1 }
            out.add(
                Channel(
                    id = "x$sid",
                    num = num,
                    name = o.str("name").trim(),
                    logo = o.str("stream_icon").takeIf { it.isNotBlank() },
                    url = "$base/live/${p.username}/${p.password}/$sid.$ext",
                    categoryId = o.str("category_id"),
                    epgId = o.str("epg_channel_id").takeIf { it.isNotBlank() },
                    streamId = sid
                )
            )
        }
        return out
    }

    fun shortEpg(streamId: String): List<Programme> {
        val o = JSONObject(api("get_short_epg", "&stream_id=$streamId&limit=8"))
        val arr = o.optJSONArray("epg_listings") ?: return emptyList()
        val out = ArrayList<Programme>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val start = e.str("start_timestamp").toLongOrNull() ?: continue
            val stop = e.str("stop_timestamp").toLongOrNull() ?: continue
            out.add(Programme(start * 1000, stop * 1000, b64(e.str("title")), b64(e.str("description"))))
        }
        out.sortBy { it.start }
        return out
    }

    private fun b64(s: String): String = try {
        String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8).trim()
    } catch (e: Exception) {
        s
    }
}
