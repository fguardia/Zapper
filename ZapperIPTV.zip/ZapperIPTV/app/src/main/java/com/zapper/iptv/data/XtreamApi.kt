package com.zapper.iptv.data

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.IOException
import java.net.URLEncoder
import java.util.TreeMap

/** Minimal Xtream Codes "player_api.php" client. */
class XtreamApi(private val p: Playlist) {

    val base: String = p.server.trim().trimEnd('/').let {
        if (it.startsWith("http://", true) || it.startsWith("https://", true)) it else "http://$it"
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun url(action: String?, extra: String = ""): String {
        val sb = StringBuilder("$base/player_api.php?username=${enc(p.username)}&password=${enc(p.password)}")
        if (action != null) sb.append("&action=").append(action)
        sb.append(extra)
        return sb.toString()
    }

    private fun api(action: String? = null, extra: String = ""): String =
        Net.getString(url(action, extra), p.userAgent)

    private fun <T> apiStream(action: String, block: (InputStream) -> T): T =
        Net.open(url(action), p.userAgent).use { r ->
            val body = r.body ?: throw IOException("Empty response")
            block(body.byteStream())
        }

    /** Returns null when login is OK, otherwise a readable error. */
    fun checkLogin(): String? {
        val txt = api()
        val o = try { JSONObject(txt) } catch (e: Exception) { return "The server did not return a valid Xtream response" }
        val ui = o.optJSONObject("user_info") ?: return "The server did not return account info"
        if (ui.optInt("auth", 0) != 1) return "Wrong username or password"
        val status = ui.str("status")
        if (status.isNotEmpty() && !status.equals("Active", true)) return "Account status: $status"
        return null
    }

    // ------------------------------------------------------------ live TV

    fun categories(): List<Category> = categoriesFor("get_live_categories")

    private fun categoriesFor(action: String): List<Category> {
        val txt = api(action).trim()
        if (!txt.startsWith("[")) return emptyList()
        val arr = JSONArray(txt)
        val out = ArrayList<Category>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Category(o.str("category_id"), o.str("category_name").trim()))
        }
        return out
    }

    fun channels(): List<Channel> {
        val rows = apiStream("get_live_streams") {
            JsonStream.readObjects(it, setOf("num", "name", "stream_id", "stream_icon", "epg_channel_id", "category_id"))
        }
        val ext = if (p.useHls) "m3u8" else "ts"
        val out = ArrayList<Channel>(rows.size)
        rows.forEachIndexed { i, m ->
            val sid = m["stream_id"].orEmpty()
            if (sid.isEmpty()) return@forEachIndexed
            val num = (m["num"]?.toDoubleOrNull()?.toInt() ?: 0).let { if (it > 0) it else i + 1 }
            out.add(
                Channel(
                    id = "x$sid",
                    num = num,
                    name = m["name"].orEmpty().trim(),
                    logo = m["stream_icon"].cleanUrl(),
                    url = "$base/live/${p.username}/${p.password}/$sid.$ext",
                    categoryId = m["category_id"].orEmpty(),
                    epgId = m["epg_channel_id"]?.takeIf { it.isNotBlank() && it != "null" },
                    streamId = sid
                )
            )
        }
        return out
    }

    fun shortEpg(streamId: String): List<Programme> {
        val o = JSONObject(api("get_short_epg", "&stream_id=$streamId&limit=8"))
        val arr = o.optJSONArray("epg_listings") ?: return emptyList()
        val out = ArrayList<Programme>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val start = e.str("start_timestamp").toLongOrNull() ?: continue
            val stop = e.str("stop_timestamp").toLongOrNull() ?: continue
            out.add(Programme(start * 1000, stop * 1000, b64(e.str("title")), b64(e.str("description"))))
        }
        out.sortBy { it.start }
        return out
    }

    // ------------------------------------------------------------ movies

    fun vodCategories(): List<Category> = categoriesFor("get_vod_categories")

    fun movies(): List<VodItem> {
        val rows = apiStream("get_vod_streams") {
            JsonStream.readObjects(it, setOf("stream_id", "name", "stream_icon", "category_id", "container_extension", "rating", "added"))
        }
        return rows.mapNotNull { m ->
            val id = m["stream_id"]?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val ext = m["container_extension"].orEmpty().ifBlank { "mp4" }
            VodItem(
                id = id,
                kind = VodItem.MOVIE,
                name = m["name"].orEmpty().trim(),
                poster = m["stream_icon"].cleanUrl(),
                categoryId = m["category_id"].orEmpty(),
                rating = m["rating"]?.takeIf { it.isNotBlank() && it != "null" && it != "0" },
                added = m["added"]?.toLongOrNull() ?: 0L,
                url = "$base/movie/${p.username}/${p.password}/$id.$ext"
            )
        }
    }

    fun movieDetails(item: VodItem): VodDetails {
        val o = JSONObject(api("get_vod_info", "&vod_id=${item.id}"))
        val info = o.optJSONObject("info")
        return VodDetails(
            title = item.name,
            plot = info?.str("plot").orEmpty().ifBlank { info?.str("description").orEmpty() },
            genre = info?.str("genre").orEmpty(),
            year = info?.str("releasedate").orEmpty().ifBlank { info?.str("release_date").orEmpty() }.take(4),
            duration = info?.str("duration").orEmpty(),
            rating = info?.str("rating").orEmpty().ifBlank { item.rating.orEmpty() },
            cast = info?.str("cast").orEmpty().ifBlank { info?.str("actors").orEmpty() },
            director = info?.str("director").orEmpty(),
            poster = info?.str("movie_image").cleanUrl() ?: info?.str("cover_big").cleanUrl() ?: item.poster,
            backdrop = backdrop(info)
        )
    }

    // ------------------------------------------------------------ series

    fun seriesCategories(): List<Category> = categoriesFor("get_series_categories")

    fun series(): List<VodItem> {
        val rows = apiStream("get_series") {
            JsonStream.readObjects(it, setOf("series_id", "name", "cover", "category_id", "rating", "last_modified"))
        }
        return rows.mapNotNull { m ->
            val id = m["series_id"]?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            VodItem(
                id = id,
                kind = VodItem.SERIES,
                name = m["name"].orEmpty().trim(),
                poster = m["cover"].cleanUrl(),
                categoryId = m["category_id"].orEmpty(),
                rating = m["rating"]?.takeIf { it.isNotBlank() && it != "null" && it != "0" },
                added = m["last_modified"]?.toLongOrNull() ?: 0L,
                url = null
            )
        }
    }

    fun seriesDetails(item: VodItem): VodDetails {
        val o = JSONObject(api("get_series_info", "&series_id=${item.id}"))
        val info = o.optJSONObject("info")
        val seasons = TreeMap<Int, MutableList<Episode>>()

        fun addEpisode(e: JSONObject, seasonHint: Int) {
            val id = e.str("id")
            if (id.isEmpty()) return
            val season = e.str("season").toIntOrNull() ?: seasonHint
            val ext = e.str("container_extension").ifBlank { "mp4" }
            val ei = e.optJSONObject("info")
            seasons.getOrPut(season) { ArrayList() }.add(
                Episode(
                    id = id,
                    season = season,
                    num = e.str("episode_num").toIntOrNull() ?: 0,
                    title = e.str("title").trim(),
                    plot = ei?.str("plot").orEmpty(),
                    image = ei?.str("movie_image").cleanUrl(),
                    duration = ei?.str("duration").orEmpty(),
                    url = "$base/series/${p.username}/${p.password}/$id.$ext"
                )
            )
        }

        when (val eps = o.opt("episodes")) {
            is JSONObject -> {
                val keys = eps.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val arr = eps.optJSONArray(k) ?: continue
                    for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { addEpisode(it, k.toIntOrNull() ?: 1) }
                }
            }
            is JSONArray -> {
                for (i in 0 until eps.length()) {
                    val arr = eps.optJSONArray(i) ?: continue
                    for (j in 0 until arr.length()) arr.optJSONObject(j)?.let { addEpisode(it, i + 1) }
                }
            }
        }
        seasons.values.forEach { list -> list.sortBy { it.num } }

        return VodDetails(
            title = item.name,
            plot = info?.str("plot").orEmpty(),
            genre = info?.str("genre").orEmpty(),
            year = info?.str("releaseDate").orEmpty().ifBlank { info?.str("release_date").orEmpty() }.take(4),
            duration = info?.str("episode_run_time").orEmpty().let { if (it.isNotBlank() && it != "0") "$it min" else "" },
            rating = info?.str("rating").orEmpty().ifBlank { item.rating.orEmpty() },
            cast = info?.str("cast").orEmpty(),
            director = info?.str("director").orEmpty(),
            poster = info?.str("cover").cleanUrl() ?: item.poster,
            backdrop = backdrop(info),
            seasons = seasons
        )
    }

    private fun backdrop(info: JSONObject?): String? {
        if (info == null) return null
        info.optJSONArray("backdrop_path")?.let { a ->
            for (i in 0 until a.length()) a.optString(i).cleanUrl()?.let { return it }
        }
        return info.str("backdrop_path").cleanUrl()
    }

    private fun b64(s: String): String = try {
        String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8).trim()
    } catch (e: Exception) {
        s
    }
}
