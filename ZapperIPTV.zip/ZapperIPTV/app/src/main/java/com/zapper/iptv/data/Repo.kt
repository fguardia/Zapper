package com.zapper.iptv.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream

/** In-memory store for the active playlist's channels and guide. */
object Repo {
    var playlist: Playlist? = null
        private set
    var categories: List<Category> = emptyList()
        private set
    var channels: List<Channel> = emptyList()
        private set

    private var epgUrlFromPlaylist: String? = null
    private val epg = ConcurrentHashMap<String, List<Programme>>()
    private val fetchedAt = ConcurrentHashMap<String, Long>()

    suspend fun load(p: Playlist) = withContext(Dispatchers.IO) {
        epg.clear()
        fetchedAt.clear()
        if (p.type == Playlist.XTREAM) {
            val api = XtreamApi(p)
            api.checkLogin()?.let { throw IOException(it) }
            val cats = api.categories()
            val chans = api.channels()
            val used = chans.mapTo(HashSet()) { it.categoryId }
            categories = cats.filter { it.id in used }
            channels = chans
            epgUrlFromPlaylist = null
        } else {
            val res = Net.open(p.m3uUrl, p.userAgent).use { r ->
                val body = r.body ?: throw IOException("Empty playlist")
                M3uParser.parse(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 65536))
            }
            categories = res.categories
            channels = res.channels
            epgUrlFromPlaylist = res.epgUrl
            VodRepo.setFromM3u(
                p.id,
                VodRepo.Section(res.movieCategories, res.movies),
                VodRepo.Section(res.seriesCategories, res.series)
            )
        }
        playlist = p
    }

    /** Xtream without a custom EPG URL uses the per-channel short EPG API. */
    fun usesShortEpg(): Boolean {
        val p = playlist ?: return false
        return p.type == Playlist.XTREAM && p.epgUrl.isBlank()
    }

    /** Downloads the XMLTV guide (plain or .gz). Returns true if something was loaded. */
    suspend fun loadXmltv(): Boolean = withContext(Dispatchers.IO) {
        val p = playlist ?: return@withContext false
        val url = p.epgUrl.trim().ifEmpty { epgUrlFromPlaylist ?: "" }
        if (url.isEmpty()) return@withContext false
        val wanted = channels.mapNotNullTo(HashSet()) { it.epgId?.lowercase() }
        if (wanted.isEmpty()) return@withContext false
        val now = System.currentTimeMillis()
        Net.open(url, p.userAgent).use { r ->
            val body = r.body ?: return@withContext false
            var stream: InputStream = BufferedInputStream(body.byteStream(), 65536)
            stream.mark(4)
            val b1 = stream.read()
            val b2 = stream.read()
            stream.reset()
            if (b1 == 0x1f && b2 == 0x8b) stream = GZIPInputStream(stream, 65536)
            val map = XmltvParser.parse(stream, wanted, now - 3 * 3_600_000L, now + 36 * 3_600_000L)
            epg.putAll(map)
            map.isNotEmpty()
        }
    }

    private fun key(ch: Channel): String =
        if (usesShortEpg() && ch.streamId != null) "x:${ch.streamId}" else ch.epgId?.lowercase() ?: ""

    fun cachedProgrammes(ch: Channel): List<Programme>? {
        val k = key(ch)
        return if (k.isEmpty()) null else epg[k]
    }

    suspend fun programmes(ch: Channel): List<Programme> = withContext(Dispatchers.IO) {
        val k = key(ch)
        if (k.isEmpty()) return@withContext emptyList()
        val p = playlist
        val sid = ch.streamId
        if (usesShortEpg() && p != null && sid != null) {
            val now = System.currentTimeMillis()
            val cached = epg[k]
            val stale = cached == null ||
                now - (fetchedAt[k] ?: 0L) > 10 * 60_000L ||
                (cached.lastOrNull()?.end ?: 0L) < now
            if (stale) {
                try {
                    epg[k] = XtreamApi(p).shortEpg(sid)
                    fetchedAt[k] = now
                } catch (e: Exception) {
                    // Guide is optional; ignore network errors.
                }
            }
        }
        epg[k] ?: emptyList()
    }
}
