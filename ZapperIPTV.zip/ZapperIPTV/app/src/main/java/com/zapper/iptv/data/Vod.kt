package com.zapper.iptv.data

import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.InputStreamReader
import java.util.Locale

data class VodItem(
    val id: String,
    val kind: String,
    val name: String,
    val poster: String?,
    val categoryId: String,
    val rating: String?,
    val added: Long,
    /** Direct play URL. Null for Xtream series (episodes come from the details call). */
    val url: String?
) {
    val key: String get() = "$kind:$id"

    companion object {
        const val MOVIE = "movie"
        const val SERIES = "series"
    }
}

data class Episode(
    val id: String,
    val season: Int,
    val num: Int,
    val title: String,
    val plot: String,
    val image: String?,
    val duration: String,
    val url: String
) {
    val key: String get() = "ep:$id"
}

data class VodDetails(
    val title: String,
    val plot: String = "",
    val genre: String = "",
    val year: String = "",
    val duration: String = "",
    val rating: String = "",
    val cast: String = "",
    val director: String = "",
    val poster: String? = null,
    val backdrop: String? = null,
    val seasons: Map<Int, List<Episode>> = emptyMap()
)

fun formatMs(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%d:%02d", m, sec)
}

fun String?.cleanUrl(): String? =
    this?.trim()?.takeIf { it.isNotEmpty() && it != "null" && !it.startsWith("[") }

/** Memory-friendly reader for huge Xtream lists (tens of thousands of movies). */
object JsonStream {
    fun readObjects(input: InputStream, fields: Set<String>): List<Map<String, String>> {
        val out = ArrayList<Map<String, String>>()
        JsonReader(InputStreamReader(input, Charsets.UTF_8)).use { r ->
            r.isLenient = true
            if (r.peek() != JsonToken.BEGIN_ARRAY) {
                r.skipValue()
                return out
            }
            r.beginArray()
            while (r.hasNext()) {
                if (r.peek() != JsonToken.BEGIN_OBJECT) {
                    r.skipValue()
                    continue
                }
                val m = HashMap<String, String>(fields.size * 2)
                r.beginObject()
                while (r.hasNext()) {
                    val name = r.nextName()
                    if (name in fields) {
                        readScalar(r)?.let { m[name] = it }
                    } else {
                        r.skipValue()
                    }
                }
                r.endObject()
                out.add(m)
            }
            r.endArray()
        }
        return out
    }

    private fun readScalar(r: JsonReader): String? = when (r.peek()) {
        JsonToken.STRING, JsonToken.NUMBER -> r.nextString()
        JsonToken.BOOLEAN -> r.nextBoolean().toString()
        JsonToken.NULL -> {
            r.nextNull()
            null
        }
        else -> {
            r.skipValue()
            null
        }
    }
}

object VodRepo {
    class Section(val categories: List<Category>, val items: List<VodItem>) {
        val byId: Map<String, VodItem> by lazy { items.associateBy { it.id } }
    }

    private var playlistId: String? = null
    private val sections = HashMap<String, Section>()
    private val details = HashMap<String, VodDetails>()

    @Synchronized
    private fun switchTo(pid: String) {
        if (playlistId != pid) {
            sections.clear()
            details.clear()
            playlistId = pid
        }
    }

    @Synchronized
    fun setFromM3u(pid: String, movies: Section, series: Section) {
        switchTo(pid)
        sections[VodItem.MOVIE] = movies
        sections[VodItem.SERIES] = series
    }

    @Synchronized
    fun clear(kind: String) {
        sections.remove(kind)
        details.clear()
    }

    @Synchronized
    private fun cached(pid: String, kind: String): Section? {
        switchTo(pid)
        return sections[kind]
    }

    @Synchronized
    fun find(kind: String, id: String): VodItem? = sections[kind]?.byId?.get(id)

    suspend fun section(p: Playlist, kind: String): Section = withContext(Dispatchers.IO) {
        cached(p.id, kind)?.let { return@withContext it }
        val s = if (p.type == Playlist.XTREAM) {
            val api = XtreamApi(p)
            if (kind == VodItem.MOVIE) Section(api.vodCategories(), api.movies())
            else Section(api.seriesCategories(), api.series())
        } else {
            // M3U: movies and series come from the same playlist file.
            Repo.load(p)
            cached(p.id, kind) ?: Section(emptyList(), emptyList())
        }
        synchronized(this@VodRepo) {
            if (playlistId == p.id) sections[kind] = s
        }
        s
    }

    suspend fun details(p: Playlist, item: VodItem): VodDetails = withContext(Dispatchers.IO) {
        synchronized(this@VodRepo) { details[item.key] }?.let { return@withContext it }
        val d = if (p.type == Playlist.XTREAM && item.url == null) {
            XtreamApi(p).seriesDetails(item)
        } else if (p.type == Playlist.XTREAM) {
            try {
                XtreamApi(p).movieDetails(item)
            } catch (e: Exception) {
                VodDetails(title = item.name, poster = item.poster, rating = item.rating.orEmpty())
            }
        } else {
            VodDetails(title = item.name, poster = item.poster, rating = item.rating.orEmpty())
        }
        synchronized(this@VodRepo) { details[item.key] = d }
        d
    }
}

/** Remembers playback positions and watched state per playlist. */
class ResumeStore(context: Context, playlistId: String) {
    private val sp = context.getSharedPreferences("resume_$playlistId", Context.MODE_PRIVATE)

    fun position(key: String): Long = sp.getLong("p_$key", 0L)
    fun duration(key: String): Long = sp.getLong("d_$key", 0L)
    fun isWatched(key: String): Boolean = sp.getBoolean("w_$key", false)

    fun save(key: String, pos: Long, dur: Long) {
        if (dur > 0 && pos > dur - 120_000L) {
            markWatched(key)
            return
        }
        if (pos < 30_000L) return
        sp.edit()
            .putLong("p_$key", pos)
            .putLong("d_$key", dur)
            .putLong("t_$key", System.currentTimeMillis())
            .apply()
    }

    fun markWatched(key: String) {
        sp.edit().remove("p_$key").remove("d_$key").remove("t_$key").putBoolean("w_$key", true).apply()
    }

    fun touchSeries(seriesId: String) {
        sp.edit().putLong("s_$seriesId", System.currentTimeMillis()).apply()
    }

    /** Movie ids with a saved position, most recent first. */
    fun moviesInProgress(): List<String> = recent("t_${VodItem.MOVIE}:")

    /** Series ids watched recently, most recent first. */
    fun recentSeries(): List<String> = recent("s_")

    private fun recent(prefix: String): List<String> =
        sp.all.entries
            .filter { it.key.startsWith(prefix) }
            .sortedByDescending { (it.value as? Long) ?: 0L }
            .map { it.key.removePrefix(prefix) }
}
