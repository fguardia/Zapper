package com.zapper.iptv.data

import java.io.BufferedReader

object M3uParser {

    class Result(
        val categories: List<Category>,
        val channels: List<Channel>,
        val epgUrl: String?,
        val movieCategories: List<Category>,
        val movies: List<VodItem>,
        val seriesCategories: List<Category>,
        val series: List<VodItem>
    )

    private val attrRe = Regex("([A-Za-z0-9_-]+)=\"([^\"]*)\"")

    fun parse(reader: BufferedReader): Result {
        var epgUrl: String? = null
        val cats = LinkedHashMap<String, Category>()
        val out = ArrayList<Channel>()
        val movieCats = LinkedHashMap<String, Category>()
        val movies = ArrayList<VodItem>()
        val seriesCats = LinkedHashMap<String, Category>()
        val series = ArrayList<VodItem>()
        var name: String? = null
        var attrs: Map<String, String> = emptyMap()
        var group: String? = null

        while (true) {
            val line = reader.readLine()?.trim() ?: break
            if (line.isEmpty()) continue
            when {
                line.startsWith("#EXTM3U") -> {
                    val a = parseAttrs(line)
                    epgUrl = (a["url-tvg"] ?: a["x-tvg-url"])
                        ?.split(",")?.firstOrNull()?.trim()?.takeIf { it.isNotEmpty() }
                }
                line.startsWith("#EXTINF") -> {
                    attrs = parseAttrs(line)
                    name = displayName(line)
                    group = attrs["group-title"]
                }
                line.startsWith("#EXTGRP:") -> group = line.substringAfter(":").trim()
                line.startsWith("#") -> Unit
                else -> {
                    val n = name
                    if (n != null) {
                        val g = group?.trim()?.takeIf { it.isNotEmpty() } ?: "Uncategorized"
                        val cid = "g:$g"
                        val kind = kindOf(line)
                        val title = n.ifBlank { attrs["tvg-name"] ?: "Item ${out.size + movies.size + series.size + 1}" }
                        if (kind == null) {
                            if (!cats.containsKey(cid)) cats[cid] = Category(cid, g)
                            val idx = out.size + 1
                            out.add(
                                Channel(
                                    id = "m" + Integer.toHexString(title.hashCode()) + Integer.toHexString(line.hashCode()),
                                    num = attrs["tvg-chno"]?.toIntOrNull() ?: idx,
                                    name = title,
                                    logo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() },
                                    url = line,
                                    categoryId = cid,
                                    epgId = attrs["tvg-id"]?.takeIf { it.isNotBlank() },
                                    streamId = null
                                )
                            )
                        } else {
                            val catMap = if (kind == VodItem.MOVIE) movieCats else seriesCats
                            if (!catMap.containsKey(cid)) catMap[cid] = Category(cid, g)
                            val item = VodItem(
                                id = "u" + Integer.toHexString(line.hashCode()) + Integer.toHexString(title.hashCode()),
                                kind = kind,
                                name = title,
                                poster = attrs["tvg-logo"]?.takeIf { it.isNotBlank() },
                                categoryId = cid,
                                rating = null,
                                added = 0L,
                                url = line
                            )
                            if (kind == VodItem.MOVIE) movies.add(item) else series.add(item)
                        }
                    }
                    name = null
                    attrs = emptyMap()
                    group = null
                }
            }
        }
        return Result(
            cats.values.toList(), out, epgUrl,
            movieCats.values.toList(), movies,
            seriesCats.values.toList(), series
        )
    }

    private fun parseAttrs(line: String): Map<String, String> {
        val map = HashMap<String, String>()
        attrRe.findAll(line).forEach { map[it.groupValues[1].lowercase()] = it.groupValues[2] }
        return map
    }

    /** Channel name is the text after the comma that follows the attributes. */
    private fun displayName(line: String): String {
        val lastQuote = line.lastIndexOf('"')
        val comma = line.indexOf(',', if (lastQuote >= 0) lastQuote else 0)
        return if (comma >= 0) line.substring(comma + 1).trim() else ""
    }

    /** null = live channel. */
    private fun kindOf(url: String): String? {
        val u = url.lowercase().substringBefore('?')
        return when {
            u.contains("/series/") -> VodItem.SERIES
            u.contains("/movie/") || u.endsWith(".mp4") || u.endsWith(".mkv") || u.endsWith(".avi") -> VodItem.MOVIE
            else -> null
        }
    }
}
