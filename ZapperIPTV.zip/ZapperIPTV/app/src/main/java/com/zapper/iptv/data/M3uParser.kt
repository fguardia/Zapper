package com.zapper.iptv.data

import java.io.BufferedReader

object M3uParser {

    class Result(val categories: List<Category>, val channels: List<Channel>, val epgUrl: String?)

    private val attrRe = Regex("([A-Za-z0-9_-]+)=\"([^\"]*)\"")

    fun parse(reader: BufferedReader): Result {
        var epgUrl: String? = null
        val cats = LinkedHashMap<String, Category>()
        val out = ArrayList<Channel>()
        var name: String? = null
        var attrs: Map<String, String> = emptyMap()
        var group: String? = null

        while (true) {
            val line = reader.readLine()?.trim() ?: break
            if (line.isEmpty()) continue
            when {
                line.startsWith("#EXTM3U") -> {
                    val a = parseAttrs(line)
                    epgUrl = (a["url-tvg"] ?: a["x-tvg-url"])
                        ?.split(",")?.firstOrNull()?.trim()?.takeIf { it.isNotEmpty() }
                }
                line.startsWith("#EXTINF") -> {
                    attrs = parseAttrs(line)
                    name = displayName(line)
                    group = attrs["group-title"]
                }
                line.startsWith("#EXTGRP:") -> group = line.substringAfter(":").trim()
                line.startsWith("#") -> Unit
                else -> {
                    val n = name
                    if (n != null && !isVod(line)) {
                        val g = group?.trim()?.takeIf { it.isNotEmpty() } ?: "Uncategorized"
                        val cid = "g:$g"
                        if (!cats.containsKey(cid)) cats[cid] = Category(cid, g)
                        val idx = out.size + 1
                        val title = n.ifBlank { attrs["tvg-name"] ?: "Channel $idx" }
                        out.add(
                            Channel(
                                id = "m" + Integer.toHexString(title.hashCode()) + Integer.toHexString(line.hashCode()),
                                num = attrs["tvg-chno"]?.toIntOrNull() ?: idx,
                                name = title,
                                logo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() },
                                url = line,
                                categoryId = cid,
                                epgId = attrs["tvg-id"]?.takeIf { it.isNotBlank() },
                                streamId = null
                            )
                        )
                    }
                    name = null
                    attrs = emptyMap()
                    group = null
                }
            }
        }
        return Result(cats.values.toList(), out, epgUrl)
    }

    private fun parseAttrs(line: String): Map<String, String> {
        val map = HashMap<String, String>()
        attrRe.findAll(line).forEach { map[it.groupValues[1].lowercase()] = it.groupValues[2] }
        return map
    }

    /** Channel name is the text after the comma that follows the attributes. */
    private fun displayName(line: String): String {
        val lastQuote = line.lastIndexOf('"')
        val comma = line.indexOf(',', if (lastQuote >= 0) lastQuote else 0)
        return if (comma >= 0) line.substring(comma + 1).trim() else ""
    }

    /** Movies and series are skipped; this app focuses on live TV. */
    private fun isVod(url: String): Boolean {
        val u = url.lowercase()
        return u.contains("/movie/") || u.contains("/series/") ||
            u.endsWith(".mp4") || u.endsWith(".mkv") || u.endsWith(".avi")
    }
}
