package com.zapper.iptv.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zapper.iptv.R
import com.zapper.iptv.data.Playlist
import com.zapper.iptv.data.Prefs
import com.zapper.iptv.data.ResumeStore
import com.zapper.iptv.data.VodItem
import com.zapper.iptv.data.VodRepo
import kotlinx.coroutines.launch

/** Poster grid for Movies or Series. */
class VodActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_KIND = "kind"
        private const val CAT_CONTINUE = "__continue"
        private const val CAT_RECENT = "__recent"
        private const val CAT_ALL = "__all"
        private const val CAT_SEARCH = "__search"

        fun newIntent(ctx: Context, kind: String): Intent =
            Intent(ctx, VodActivity::class.java).putExtra(EXTRA_KIND, kind)
    }

    private lateinit var kind: String
    private lateinit var playlist: Playlist
    private lateinit var resume: ResumeStore

    private lateinit var catList: RecyclerView
    private lateinit var grid: RecyclerView
    private lateinit var header: TextView
    private lateinit var empty: View
    private lateinit var loading: View
    private lateinit var loadingText: TextView

    private lateinit var catAdapter: CategoryAdapter
    private lateinit var posterAdapter: PosterAdapter

    private var section: VodRepo.Section? = null
    private var currentCat = CAT_ALL
    private var searchQuery = ""
    private var visible: List<VodItem> = emptyList()

    private val handler = Handler(Looper.getMainLooper())
    private var pendingCat: String? = null
    private val applyCategory = Runnable {
        val id = pendingCat ?: return@Runnable
        if (id != currentCat) selectCategory(id)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        kind = intent.getStringExtra(EXTRA_KIND) ?: VodItem.MOVIE
        val p = Prefs(this).active()
        if (p == null) {
            finish()
            return
        }
        playlist = p
        resume = ResumeStore(this, p.id)
        setContentView(R.layout.activity_vod)

        catList = findViewById(R.id.vodCatList)
        grid = findViewById(R.id.grid)
        header = findViewById(R.id.gridHeader)
        empty = findViewById(R.id.gridEmpty)
        loading = findViewById(R.id.vodLoading)
        loadingText = findViewById(R.id.vodLoadingText)
        findViewById<TextView>(R.id.vodTitle).setText(
            if (kind == VodItem.MOVIE) R.string.movies_title else R.string.series_title
        )
        findViewById<View>(R.id.btnVodSearch).setOnClickListener { showSearch() }
        findViewById<View>(R.id.btnVodReload).setOnClickListener { load(force = true) }

        catAdapter = CategoryAdapter(
            onFocused = { item ->
                pendingCat = item.id
                handler.removeCallbacks(applyCategory)
                handler.postDelayed(applyCategory, 250)
            },
            onClicked = { item ->
                handler.removeCallbacks(applyCategory)
                if (currentCat != item.id) selectCategory(item.id)
                focusGridAt(0)
            }
        )
        catList.layoutManager = LinearLayoutManager(this)
        catList.itemAnimator = null
        catList.adapter = catAdapter

        // Size the grid so posters keep a 2:3 shape.
        val dm = resources.displayMetrics
        val gridWidth = dm.widthPixels - resources.getDimensionPixelSize(R.dimen.cat_width) - (32 * dm.density).toInt()
        val minCell = (150 * dm.density).toInt()
        val span = (gridWidth / minCell).coerceIn(3, 8)
        val cellWidth = gridWidth / span
        val posterHeight = ((cellWidth - 20 * dm.density) * 1.5f).toInt()
        posterAdapter = PosterAdapter(posterHeight, resume) { item ->
            startActivity(DetailActivity.newIntent(this, item.kind, item.id))
        }
        grid.layoutManager = GridLayoutManager(this, span)
        grid.itemAnimator = null
        grid.adapter = posterAdapter

        load(force = false)
    }

    override fun onResume() {
        super.onResume()
        if (section != null) {
            // Progress may have changed after watching something.
            buildCategories()
            if (currentCat == CAT_CONTINUE) {
                visible = itemsFor(currentCat)
                posterAdapter.items = visible
            } else {
                posterAdapter.notifyItemRangeChanged(0, posterAdapter.itemCount)
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun load(force: Boolean) {
        loadingText.setText(if (kind == VodItem.MOVIE) R.string.loading_movies else R.string.loading_series)
        loading.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                if (force) VodRepo.clear(kind)
                section = VodRepo.section(playlist, kind)
            } catch (e: Exception) {
                loading.visibility = View.GONE
                AlertDialog.Builder(this@VodActivity)
                    .setTitle(R.string.load_failed)
                    .setMessage(e.message ?: e.javaClass.simpleName)
                    .setPositiveButton(R.string.retry) { _, _ -> load(force) }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> finish() }
                    .setCancelable(false)
                    .show()
                return@launch
            }
            loading.visibility = View.GONE
            buildCategories()
            val start = if (catAdapter.indexOf(CAT_CONTINUE) != null) CAT_CONTINUE else CAT_ALL
            selectCategory(start)
            focusCategory()
        }
    }

    private fun continueItems(): List<VodItem> {
        val s = section ?: return emptyList()
        val ids = if (kind == VodItem.MOVIE) resume.moviesInProgress() else resume.recentSeries()
        return ids.mapNotNull { s.byId[it] }.take(60)
    }

    private fun itemsFor(cat: String): List<VodItem> {
        val s = section ?: return emptyList()
        return when (cat) {
            CAT_CONTINUE -> continueItems()
            CAT_RECENT -> s.items.filter { it.added > 0 }.sortedByDescending { it.added }.take(300)
            CAT_ALL -> s.items
            CAT_SEARCH -> s.items.filter { it.name.contains(searchQuery, ignoreCase = true) }
            else -> s.items.filter { it.categoryId == cat }
        }
    }

    private fun buildCategories() {
        val s = section ?: return
        val counts = s.items.groupingBy { it.categoryId }.eachCount()
        val list = ArrayList<CatItem>()
        val cont = continueItems().size
        if (cont > 0) list.add(CatItem(CAT_CONTINUE, getString(R.string.continue_watching), cont))
        if (s.items.any { it.added > 0 }) {
            list.add(CatItem(CAT_RECENT, getString(R.string.recently_added), minOf(300, s.items.count { it.added > 0 })))
        }
        list.add(CatItem(CAT_ALL, getString(R.string.all_items), s.items.size))
        s.categories.forEach { c ->
            val n = counts[c.id] ?: 0
            if (n > 0) list.add(CatItem(c.id, c.name, n))
        }
        val focusedInCats = catList.hasFocus()
        catAdapter.items = list
        catAdapter.selectedId = currentCat
        if (focusedInCats) focusCategory()
    }

    private fun selectCategory(id: String) {
        currentCat = id
        catAdapter.selectedId = id
        visible = itemsFor(id)
        posterAdapter.items = visible
        grid.scrollToPosition(0)
        val name = if (id == CAT_SEARCH) getString(R.string.search_results, searchQuery)
        else catAdapter.items.firstOrNull { it.id == id }?.name ?: ""
        header.text = "$name  (${visible.size})"
        empty.visibility = if (visible.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun focusGridAt(index: Int) {
        if (index !in visible.indices) return
        grid.scrollToPosition(index)
        grid.postDelayed({
            grid.findViewHolderForAdapterPosition(index)?.itemView?.requestFocus() ?: grid.requestFocus()
        }, 80)
    }

    private fun focusCategory() {
        val idx = catAdapter.indexOf(currentCat) ?: 0
        catList.scrollToPosition(idx)
        catList.postDelayed({
            catList.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() ?: catList.requestFocus()
        }, 80)
    }

    private fun showSearch() {
        val input = EditText(this).apply {
            hint = getString(R.string.search_title_hint)
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(R.string.search)
            .setView(input)
            .setPositiveButton(R.string.search) { _, _ -> doSearch(input.text.toString()) }
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        input.setOnEditorActionListener { _, _, _ ->
            doSearch(input.text.toString())
            dlg.dismiss()
            true
        }
        dlg.show()
    }

    private fun doSearch(q: String) {
        val query = q.trim()
        if (query.isEmpty() || section == null) return
        searchQuery = query
        selectCategory(CAT_SEARCH)
        focusGridAt(0)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK && ::grid.isInitialized && loading.visibility != View.VISIBLE) {
            if (event.action == KeyEvent.ACTION_UP && !event.isCanceled) {
                if (grid.hasFocus()) focusCategory() else finish()
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
