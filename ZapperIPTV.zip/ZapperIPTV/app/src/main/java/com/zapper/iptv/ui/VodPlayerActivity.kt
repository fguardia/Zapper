package com.zapper.iptv.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.zapper.iptv.R
import com.zapper.iptv.data.Net
import com.zapper.iptv.data.Prefs
import com.zapper.iptv.data.ResumeStore

/** Full player for movies and episodes, with resume and auto-next. */
@OptIn(UnstableApi::class)
class VodPlayerActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_URLS = "urls"
        private const val EXTRA_TITLES = "titles"
        private const val EXTRA_KEYS = "keys"
        private const val EXTRA_INDEX = "index"
        private const val EXTRA_START_OVER = "startOver"
        private const val EXTRA_SERIES_ID = "seriesId"

        fun newIntent(
            ctx: Context,
            urls: ArrayList<String>,
            titles: ArrayList<String>,
            keys: ArrayList<String>,
            index: Int,
            startOver: Boolean,
            seriesId: String?
        ): Intent = Intent(ctx, VodPlayerActivity::class.java)
            .putStringArrayListExtra(EXTRA_URLS, urls)
            .putStringArrayListExtra(EXTRA_TITLES, titles)
            .putStringArrayListExtra(EXTRA_KEYS, keys)
            .putExtra(EXTRA_INDEX, index)
            .putExtra(EXTRA_START_OVER, startOver)
            .putExtra(EXTRA_SERIES_ID, seriesId)
    }

    private lateinit var playerView: PlayerView
    private lateinit var titleView: TextView
    private lateinit var resume: ResumeStore
    private var player: ExoPlayer? = null
    private var userAgent = Net.DEFAULT_UA

    private var urls: List<String> = emptyList()
    private var titles: List<String> = emptyList()
    private var keys: List<String> = emptyList()
    private var currentIndex = 0
    private var startOver = false
    private var seriesId: String? = null
    private var restorePosition = C.TIME_UNSET

    private val handler = Handler(Looper.getMainLooper())
    private val saver = object : Runnable {
        override fun run() {
            saveProgress()
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Prefs(this).active()
        urls = intent.getStringArrayListExtra(EXTRA_URLS) ?: arrayListOf()
        if (p == null || urls.isEmpty()) {
            finish()
            return
        }
        titles = intent.getStringArrayListExtra(EXTRA_TITLES) ?: arrayListOf()
        keys = intent.getStringArrayListExtra(EXTRA_KEYS) ?: arrayListOf()
        currentIndex = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, urls.size - 1)
        startOver = intent.getBooleanExtra(EXTRA_START_OVER, false)
        seriesId = intent.getStringExtra(EXTRA_SERIES_ID)
        userAgent = p.userAgent.ifBlank { Net.DEFAULT_UA }
        resume = ResumeStore(this, p.id)

        setContentView(R.layout.activity_vod_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        playerView = findViewById(R.id.vodPlayerView)
        titleView = findViewById(R.id.vodTitleView)
        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { v -> titleView.visibility = v }
        )
        titleView.text = titles.getOrNull(currentIndex).orEmpty()
    }

    override fun onStart() {
        super.onStart()
        if (::playerView.isInitialized) {
            initPlayer()
            handler.postDelayed(saver, 10_000)
        }
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacksAndMessages(null)
        val p = player ?: return
        saveProgress()
        currentIndex = p.currentMediaItemIndex
        restorePosition = p.currentPosition
        p.removeListener(listener)
        p.release()
        player = null
        playerView.player = null
    }

    private fun initPlayer() {
        if (player != null) return
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(userAgent)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(30_000)
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(30_000)
            .build()

        val items = urls.indices.map { i ->
            val b = MediaItem.Builder()
                .setUri(urls[i])
                .setMediaId(keys.getOrNull(i) ?: urls[i])
                .setMediaMetadata(MediaMetadata.Builder().setTitle(titles.getOrNull(i)).build())
            if (urls[i].contains(".m3u8", ignoreCase = true)) b.setMimeType(MimeTypes.APPLICATION_M3U8)
            b.build()
        }
        val startPos = when {
            restorePosition != C.TIME_UNSET -> restorePosition
            startOver -> 0L
            else -> keys.getOrNull(currentIndex)?.let { resume.position(it) } ?: 0L
        }
        p.setMediaItems(items, currentIndex, startPos)
        p.addListener(listener)
        p.playWhenReady = true
        p.prepare()
        playerView.player = p
        player = p
    }

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val p = player ?: return
            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                keys.getOrNull(currentIndex)?.let { resume.markWatched(it) }
            }
            currentIndex = p.currentMediaItemIndex
            titleView.text = titles.getOrNull(currentIndex).orEmpty()
            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO ||
                reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK
            ) {
                val pos = keys.getOrNull(currentIndex)?.let { resume.position(it) } ?: 0L
                if (pos > 0) p.seekTo(pos)
            }
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED) {
                keys.getOrNull(currentIndex)?.let { resume.markWatched(it) }
                seriesId?.let { resume.touchSeries(it) }
                finish()
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(
                this@VodPlayerActivity,
                getString(R.string.playback_error, error.errorCodeName),
                Toast.LENGTH_LONG
            ).show()
            playerView.showController()
        }
    }

    private fun saveProgress() {
        val p = player ?: return
        val key = keys.getOrNull(p.currentMediaItemIndex) ?: return
        val dur = p.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L
        val pos = p.currentPosition
        if (pos <= 0) return
        resume.save(key, pos, dur)
        seriesId?.let { resume.touchSeries(it) }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!::playerView.isInitialized) return super.dispatchKeyEvent(event)
        val p = player
        val controllerShown = playerView.isControllerFullyVisible
        if (event.action == KeyEvent.ACTION_DOWN && p != null && !controllerShown) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> {
                    p.seekBack(); playerView.showController(); return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                    p.seekForward(); playerView.showController(); return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    if (p.isPlaying) p.pause() else p.play()
                    playerView.showController()
                    return true
                }
            }
        }
        if (event.keyCode == KeyEvent.KEYCODE_BACK && controllerShown) {
            if (event.action == KeyEvent.ACTION_UP) playerView.hideController()
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
