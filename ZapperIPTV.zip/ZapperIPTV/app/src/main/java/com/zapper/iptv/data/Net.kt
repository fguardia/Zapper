package com.zapper.iptv.data

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit

object Net {
    /** Most IPTV servers accept VLC's user agent. */
    const val DEFAULT_UA = "VLC/3.0.20 LibVLC/3.0.20"

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    /** Opens a URL; the caller must close the response. Throws on HTTP errors. */
    fun open(url: String, userAgent: String): Response {
        val req = Request.Builder()
            .url(url.trim())
            .header("User-Agent", userAgent.ifBlank { DEFAULT_UA })
            .build()
        val resp = client.newCall(req).execute()
        if (!resp.isSuccessful) {
            val code = resp.code
            resp.close()
            throw IOException("Server replied HTTP $code")
        }
        return resp
    }

    fun getString(url: String, userAgent: String): String =
        open(url, userAgent).use { it.body?.string() ?: "" }
}
