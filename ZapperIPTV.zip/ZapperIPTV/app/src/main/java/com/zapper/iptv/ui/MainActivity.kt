package com.zapper.iptv.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.zapper.iptv.R
import com.zapper.iptv.data.Channel
import com.zapper.iptv.data.Net
import com.zapper.iptv.data.Playlist
import com.zapper.iptv.data.Prefs
import com.zapper.iptv.data.Programme
import com.zapper.iptv.data.Repo
import com.zapper.iptv.data.VodItem
import com.zapper.iptv.data.nowNext
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    companion object {
        private const val CAT_ALL = "__all"
        private const val CAT_FAV = "__fav"
        private const val CAT_SEARCH = "__search"
    }

    private lateinit var prefs: Prefs
    private var playlist: Playlist? = null
    private var player: ExoPlayer? = null

    private lateinit var playerView: PlayerView
    private lateinit var browse: View
    private lateinit var previewSpacer: View
    private lateinit var catList: RecyclerView
    private lateinit var chanList: RecyclerView
    private lateinit var chanHeader: TextView
    private lateinit var catAdapter: CategoryAdapter
    private lateinit var chanAdapter: ChannelAdapter
    private lateinit var loading: View
    private lateinit var loadingText: TextView

    private lateinit var infoName: TextView
    private lateinit var infoNow: TextView
    private lateinit var infoTime: TextView
    private lateinit var infoProgress: ProgressBar
    private lateinit var infoDesc: TextView
    private lateinit var infoNext: TextView

    private lateinit var overlay: View
    private lateinit var ovLogo: ImageView
    private lateinit var ovName: TextView
    private lateinit var ovNow: TextView
    private lateinit var ovTime: TextView
    private lateinit var ovProgress: ProgressBar
    private lateinit var ovNext: TextView
    private lateinit var ovClock: TextView
    private lateinit var numberView: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val timeFmt by lazy { android.text.format.DateFormat.getTimeFormat(this) }

    private var fullscreen = false
    private var favs: MutableSet<String> = HashSet()
    private var currentCat = CAT_ALL
    private var visible: List<Channel> = emptyList()
    private var playing: Channel? = null
    private var infoChannel: Channel? = null
    private var searchQuery = ""
    private var retries = 0
    private var numberBuffer = ""
    private var lastBackPress = 0L
    private var infoJob: Job? = null
    private var pendingCat: String? = null
    private var pendingInfo: Channel? = null

    private var previewLeft = 0
    private var previewTop = 0
    private var previewW = 0
    private var previewH = 0

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val p = prefs.active()
        if (p == null) {
            openSetup()
            finish()
            return
        }
        playlist = p
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        bindViews()
        setupLists()
        computePreviewGeometry()
        setFullscreen(false)
        loadPlaylist()
    }

    override fun onStart() {
        super.onStart()
        if (!::playerView.isInitialized) return
        val active = prefs.active()
        if (active == null) {
            openSetup()
            finish()
            return
        }
        if (active != playlist) {
            // Playlist was switched or edited in the setup screen.
            playlist = active
            playing = null
            releasePlayer()
            initPlayer()
            loadPlaylist()
        } else {
            initPlayer()
            playing?.let { startPlayback(it) }
        }
        handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacksAndMessages(null)
        if (::playerView.isInitialized) releasePlayer()
    }

    // ---------------------------------------------------------------- setup

    private fun bindViews() {
        playerView = findViewById(R.id.playerView)
        browse = findViewById(R.id.browse)
        previewSpacer = findViewById(R.id.previewSpacer)
        catList = findViewById(R.id.catList)
        chanList = findViewById(R.id.chanList)
        chanHeader = findViewById(R.id.chanHeader)
        loading = findViewById(R.id.loading)
        loadingText = findViewById(R.id.loadingText)
        infoName = findViewById(R.id.infoName)
        infoNow = findViewById(R.id.infoNow)
        infoTime = findViewById(R.id.infoTime)
        infoProgress = findViewById(R.id.infoProgress)
        infoDesc = findViewById(R.id.infoDesc)
        infoNext = findViewById(R.id.infoNext)
        overlay = findViewById(R.id.overlay)
        ovLogo = findViewById(R.id.ovLogo)
        ovName = findViewById(R.id.ovName)
        ovNow = findViewById(R.id.ovNow)
        ovTime = findViewById(R.id.ovTime)
        ovProgress = findViewById(R.id.ovProgress)
        ovNext = findViewById(R.id.ovNext)
        ovClock = findViewById(R.id.ovClock)
        numberView = findViewById(R.id.numberView)

        findViewById<View>(R.id.btnSearch).setOnClickListener { showSearch() }
        findViewById<View>(R.id.btnReload).setOnClickListener { loadPlaylist() }
        findViewById<View>(R.id.btnSettings).setOnClickListener { openSetup() }
        findViewById<View>(R.id.btnMovies).setOnClickListener {
            startActivity(VodActivity.newIntent(this, VodItem.MOVIE))
        }
        findViewById<View>(R.id.btnSeries).setOnClickListener {
            startActivity(VodActivity.newIntent(this, VodItem.SERIES))
        }
    }

    private fun setupLists() {
        catAdapter = CategoryAdapter(
            onFocused = { item ->
                pendingCat = item.id
                handler.removeCallbacks(applyCategory)
                handler.postDelayed(applyCategory, 220)
            },
            onClicked = { item ->
                handler.removeCallbacks(applyCategory)
                if (currentCat != item.id) selectCategory(item.id)
                focusChannelAt(0)
            }
        )
        chanAdapter = ChannelAdapter(
            onFocused = { ch ->
                pendingInfo = ch
                handler.removeCallbacks(applyInfo)
                handler.postDelayed(applyInfo, 250)
            },
            onClicked = { ch ->
                if (playing?.id == ch.id && player != null) setFullscreen(true) else play(ch)
            },
            onLongClicked = { ch -> toggleFav(ch) },
            nowTitle = { ch -> nowNext(Repo.cachedProgrammes(ch)).first?.title }
        )
        catList.layoutManager = LinearLayoutManager(this)
        catList.itemAnimator = null
        catList.adapter = catAdapter
        chanList.layoutManager = LinearLayoutManager(this)
        chanList.itemAnimator = null
        chanList.adapter = chanAdapter
    }

    private val applyCategory = Runnable {
        val id = pendingCat ?: return@Runnable
        if (id != currentCat) selectCategory(id)
    }

    private val applyInfo = Runnable { pendingInfo?.let { showInfo(it) } }

    private val ticker = object : Runnable {
        override fun run() {
            infoChannel?.let { bindEpg(Repo.cachedProgrammes(it), infoNow, infoTime, infoProgress, infoNext, infoDesc) }
            if (overlay.visibility == View.VISIBLE) ovClock.text = timeFmt.format(System.currentTimeMillis())
            handler.postDelayed(this, 30_000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun computePreviewGeometry() {
        val screenW = resources.displayMetrics.widthPixels
        previewLeft = resources.getDimensionPixelSize(R.dimen.cat_width) +
            resources.getDimensionPixelSize(R.dimen.chan_width) + dp(24)
        previewTop = dp(16)
        previewW = (screenW - previewLeft - dp(20)).coerceAtLeast(dp(160))
        previewH = previewW * 9 / 16
        previewSpacer.layoutParams = previewSpacer.layoutParams.apply { height = previewTop + previewH + dp(12) }
    }

    // ---------------------------------------------------------------- player

    private fun initPlayer() {
        if (player != null) return
        val ua = playlist?.userAgent?.ifBlank { Net.DEFAULT_UA } ?: Net.DEFAULT_UA
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(30_000)
        val dataSource = DefaultDataSource.Factory(this, http)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 1_500, 3_000)
            .build()
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSource))
            .setLoadControl(loadControl)
            .build()
        p.addListener(playerListener)
        p.playWhenReady = true
        playerView.player = p
        player = p
    }

    private fun releasePlayer() {
        player?.removeListener(playerListener)
        player?.release()
        player = null
        playerView.player = null
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_READY) retries = 0
            if (state == Player.STATE_ENDED) {
                // Live MPEG-TS streams sometimes "end"; reconnect.
                player?.let { it.seekToDefaultPosition(); it.prepare() }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            val p = player ?: return
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                p.seekToDefaultPosition()
                p.prepare()
                return
            }
            if (retries < 3) {
                retries++
                handler.postDelayed({ player?.prepare() }, 1500L * retries)
            } else {
                toast(getString(R.string.stream_error, error.errorCodeName))
            }
        }
    }

    private fun startPlayback(ch: Channel) {
        val p = player ?: return
        retries = 0
        val b = MediaItem.Builder().setUri(ch.url)
        if (ch.url.contains(".m3u8", ignoreCase = true)) b.setMimeType(MimeTypes.APPLICATION_M3U8)
        p.setMediaItem(b.build())
        p.prepare()
        p.play()
    }

    private fun play(ch: Channel) {
        playing = ch
        playlist?.let { prefs.setLastChannel(it.id, ch.id) }
        chanAdapter.playingId = ch.id
        initPlayer()
        startPlayback(ch)
        if (fullscreen) showOverlay(ch)
    }

    // ---------------------------------------------------------------- loading

    private fun loadPlaylist() {
        val p = playlist ?: return
        loadingText.text = getString(R.string.loading_channels)
        loading.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                Repo.load(p)
            } catch (e: Exception) {
                loading.visibility = View.GONE
                showLoadError(e)
                return@launch
            }
            if (playlist != p) return@launch
            loading.visibility = View.GONE
            favs = prefs.favorites(p.id)
            chanAdapter.favorites = favs
            buildCategories()
            selectCategory(CAT_ALL)

            val current = playing?.let { cur -> Repo.channels.firstOrNull { it.id == cur.id } }
            if (Repo.channels.isEmpty()) {
                toast(getString(R.string.no_channels))
                catList.requestFocus()
            } else if (current != null) {
                // Reload: keep the channel that is already playing.
                playing = current
                chanAdapter.playingId = current.id
                if (!fullscreen) focusChannel(current)
            } else {
                val last = prefs.lastChannel(p.id)?.let { id -> Repo.channels.firstOrNull { it.id == id } }
                if (last != null) {
                    play(last)
                    setFullscreen(true)
                } else {
                    play(Repo.channels.first())
                    setFullscreen(false)
                }
            }

            if (!Repo.usesShortEpg()) {
                launch {
                    try {
                        if (Repo.loadXmltv()) {
                            chanAdapter.refreshAll()
                            infoChannel?.let { showInfo(it) }
                        }
                    } catch (e: Exception) {
                        // Guide is optional.
                    }
                }
            }
        }
    }

    private fun showLoadError(e: Exception) {
        AlertDialog.Builder(this)
            .setTitle(R.string.load_failed)
            .setMessage(e.message ?: e.javaClass.simpleName)
            .setPositiveButton(R.string.retry) { _, _ -> loadPlaylist() }
            .setNegativeButton(R.string.playlists) { _, _ -> openSetup() }
            .setCancelable(false)
            .show()
    }

    private fun buildCategories() {
        val counts = Repo.channels.groupingBy { it.categoryId }.eachCount()
        val items = ArrayList<CatItem>()
        items.add(CatItem(CAT_ALL, getString(R.string.all_channels), Repo.channels.size))
        items.add(CatItem(CAT_FAV, getString(R.string.favorites), Repo.channels.count { it.id in favs }))
        Repo.categories.forEach { c ->
            val n = counts[c.id] ?: 0
            if (n > 0) items.add(CatItem(c.id, c.name, n))
        }
        catAdapter.items = items
    }

    private fun channelsFor(catId: String): List<Channel> = when (catId) {
        CAT_ALL -> Repo.channels
        CAT_FAV -> Repo.channels.filter { it.id in favs }
        CAT_SEARCH -> Repo.channels.filter { it.name.contains(searchQuery, ignoreCase = true) }
        else -> Repo.channels.filter { it.categoryId == catId }
    }

    private fun selectCategory(id: String) {
        currentCat = id
        catAdapter.selectedId = id
        visible = channelsFor(id)
        chanAdapter.items = visible
        chanList.scrollToPosition(0)
        chanHeader.text = when (id) {
            CAT_SEARCH -> getString(R.string.search_results, searchQuery)
            else -> catAdapter.items.firstOrNull { it.id == id }?.name ?: ""
        }
    }

    // ---------------------------------------------------------------- focus helpers

    private fun focusChannelAt(index: Int) {
        if (index < 0 || index >= visible.size) return
        (chanList.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(index, dp(140))
        chanList.postDelayed({
            chanList.findViewHolderForAdapterPosition(index)?.itemView?.requestFocus()
                ?: chanList.requestFocus()
        }, 60)
    }

    private fun focusChannel(ch: Channel) {
        var idx = visible.indexOfFirst { it.id == ch.id }
        if (idx < 0) {
            selectCategory(CAT_ALL)
            idx = visible.indexOfFirst { it.id == ch.id }
        }
        focusChannelAt(idx)
        showInfo(ch)
    }

    private fun focusSelectedCategory() {
        val idx = catAdapter.indexOf(currentCat) ?: 0
        catList.scrollToPosition(idx)
        catList.postDelayed({
            catList.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus()
                ?: catList.requestFocus()
        }, 60)
    }

    // ---------------------------------------------------------------- modes

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        val lp = playerView.layoutParams as FrameLayout.LayoutParams
        if (on) {
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT
            lp.height = ViewGroup.LayoutParams.MATCH_PARENT
            lp.setMargins(0, 0, 0, 0)
            lp.gravity = Gravity.NO_GRAVITY
            playerView.layoutParams = lp
            browse.visibility = View.GONE
            showOverlay(playing)
        } else {
            lp.width = previewW
            lp.height = previewH
            lp.setMargins(previewLeft, previewTop, 0, 0)
            lp.gravity = Gravity.TOP or Gravity.START
            playerView.layoutParams = lp
            overlay.visibility = View.GONE
            browse.visibility = View.VISIBLE
            playing?.let { focusChannel(it) } ?: focusSelectedCategory()
        }
    }

    // ---------------------------------------------------------------- EPG display

    private fun fmt(t: Long): String = timeFmt.format(t)

    private fun bindEpg(
        progs: List<Programme>?,
        now: TextView,
        time: TextView,
        bar: ProgressBar,
        next: TextView,
        desc: TextView?
    ) {
        val (cur, nxt) = nowNext(progs)
        if (cur != null) {
            now.text = cur.title
            time.text = "${fmt(cur.start)} – ${fmt(cur.end)}"
            val span = (cur.end - cur.start).coerceAtLeast(1)
            bar.progress = (((System.currentTimeMillis() - cur.start) * 1000) / span).toInt().coerceIn(0, 1000)
            bar.visibility = View.VISIBLE
            desc?.text = cur.desc
        } else {
            now.text = getString(R.string.no_info)
            time.text = ""
            bar.visibility = View.INVISIBLE
            desc?.text = ""
        }
        next.text = if (nxt != null) getString(R.string.next_fmt, fmt(nxt.start), nxt.title) else ""
    }

    private fun showInfo(ch: Channel) {
        infoChannel = ch
        infoName.text = "${ch.num}   ${ch.name}"
        bindEpg(Repo.cachedProgrammes(ch), infoNow, infoTime, infoProgress, infoNext, infoDesc)
        infoJob?.cancel()
        infoJob = lifecycleScope.launch {
            val progs = Repo.programmes(ch)
            if (infoChannel?.id == ch.id) {
                bindEpg(progs, infoNow, infoTime, infoProgress, infoNext, infoDesc)
                if (Repo.usesShortEpg()) chanAdapter.refreshChannel(ch.id)
            }
        }
    }

    private val hideOverlay = Runnable { overlay.visibility = View.GONE }

    private fun showOverlay(ch: Channel?) {
        val c = ch ?: return
        overlay.visibility = View.VISIBLE
        ovName.text = "${c.num}   ${c.name}"
        ovClock.text = timeFmt.format(System.currentTimeMillis())
        if (c.logo != null) {
            Glide.with(ovLogo).load(c.logo).fitCenter().into(ovLogo)
        } else {
            Glide.with(ovLogo).clear(ovLogo)
            ovLogo.setImageResource(R.drawable.ic_tv)
        }
        bindEpg(Repo.cachedProgrammes(c), ovNow, ovTime, ovProgress, ovNext, null)
        lifecycleScope.launch {
            val progs = Repo.programmes(c)
            if (playing?.id == c.id && overlay.visibility == View.VISIBLE) {
                bindEpg(progs, ovNow, ovTime, ovProgress, ovNext, null)
            }
        }
        handler.removeCallbacks(hideOverlay)
        handler.postDelayed(hideOverlay, 5_000)
    }

    // ---------------------------------------------------------------- actions

    private fun zap(dir: Int) {
        val list = if (visible.any { it.id == playing?.id }) visible else Repo.channels
        if (list.isEmpty()) return
        val i = list.indexOfFirst { it.id == playing?.id }
        val next = list[if (i < 0) 0 else (i + dir + list.size) % list.size]
        play(next)
        if (!fullscreen) focusChannel(next)
    }

    private fun toggleFav(ch: Channel) {
        val p = playlist ?: return
        val added = if (favs.contains(ch.id)) { favs.remove(ch.id); false } else { favs.add(ch.id); true }
        prefs.saveFavorites(p.id, favs)
        chanAdapter.refreshChannel(ch.id)
        val favIdx = catAdapter.indexOf(CAT_FAV)
        if (favIdx != null) {
            val ids = Repo.channels.mapTo(HashSet()) { it.id }
            val updated = catAdapter.items.toMutableList()
            updated[favIdx] = updated[favIdx].copy(count = favs.count { it in ids })
            catAdapter.items = updated
        }
        toast(getString(if (added) R.string.fav_added else R.string.fav_removed))
    }

    private fun onDigit(d: Int) {
        if (numberBuffer.length >= 5) numberBuffer = ""
        numberBuffer += d
        numberView.text = numberBuffer
        numberView.visibility = View.VISIBLE
        handler.removeCallbacks(commitNumber)
        handler.postDelayed(commitNumber, 1_500)
    }

    private val commitNumber = Runnable {
        val n = numberBuffer.toIntOrNull()
        numberBuffer = ""
        numberView.visibility = View.GONE
        val ch = n?.let { num -> Repo.channels.firstOrNull { it.num == num } }
        if (ch != null) {
            play(ch)
            if (!fullscreen) focusChannel(ch)
        } else {
            toast(getString(R.string.channel_not_found))
        }
    }

    private fun showSearch() {
        val input = EditText(this).apply {
            hint = getString(R.string.search_hint)
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(R.string.search)
            .setView(input)
            .setPositiveButton(R.string.search) { _, _ -> doSearch(input.text.toString()) }
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        input.setOnEditorActionListener { _, _, _ ->
            doSearch(input.text.toString())
            dlg.dismiss()
            true
        }
        dlg.show()
    }

    private fun doSearch(q: String) {
        val query = q.trim()
        if (query.isEmpty()) return
        searchQuery = query
        selectCategory(CAT_SEARCH)
        if (visible.isEmpty()) toast(getString(R.string.no_results)) else focusChannelAt(0)
    }

    private fun openSetup() {
        startActivity(Intent(this, SetupActivity::class.java))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- remote control

    private val fullscreenKeys = setOf(
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_MENU
    )

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!::playerView.isInitialized) return super.dispatchKeyEvent(event)
        val code = event.keyCode

        if (code == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP && !event.isCanceled) onBackKey()
            return true
        }
        if (loading.visibility == View.VISIBLE) return super.dispatchKeyEvent(event)

        if (event.action == KeyEvent.ACTION_DOWN) {
            when (code) {
                in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                    onDigit(code - KeyEvent.KEYCODE_0); return true
                }
                KeyEvent.KEYCODE_CHANNEL_UP -> { zap(+1); return true }
                KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(-1); return true }
            }
            if (fullscreen) {
                when (code) {
                    KeyEvent.KEYCODE_DPAD_UP -> { zap(-1); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { zap(+1); return true }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                        if (event.repeatCount == 0) setFullscreen(false)
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_INFO -> {
                        showOverlay(playing); return true
                    }
                    KeyEvent.KEYCODE_MENU -> {
                        playing?.let { toggleFav(it) }; return true
                    }
                }
            } else if (code == KeyEvent.KEYCODE_MENU) {
                val focused = currentFocus
                if (focused != null && chanList.hasFocus()) {
                    val pos = chanList.findContainingViewHolder(focused)?.bindingAdapterPosition ?: -1
                    if (pos in visible.indices) toggleFav(visible[pos])
                    return true
                }
            }
        } else if (fullscreen && event.action == KeyEvent.ACTION_UP && code in fullscreenKeys) {
            // Swallow key-ups that belong to fullscreen handling.
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun onBackKey() {
        if (fullscreen) {
            setFullscreen(false)
            return
        }
        if (chanList.hasFocus() && playing != null) {
            setFullscreen(true)
            return
        }
        if (!catList.hasFocus() && !chanList.hasFocus()) {
            focusSelectedCategory()
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (now - lastBackPress < 2_000) {
            finish()
        } else {
            lastBackPress = now
            toast(getString(R.string.press_back_exit))
        }
    }
}
