package com.zapper.iptv.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.zapper.iptv.R
import com.zapper.iptv.data.Channel

private const val PAYLOAD_STATE = "state"

data class CatItem(val id: String, val name: String, val count: Int)

class CategoryAdapter(
    private val onFocused: (CatItem) -> Unit,
    private val onClicked: (CatItem) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    var items: List<CatItem> = emptyList()
        set(v) {
            field = v
            notifyDataSetChanged()
        }

    var selectedId: String? = null
        set(v) {
            val old = field
            field = v
            indexOf(old)?.let { notifyItemChanged(it, PAYLOAD_STATE) }
            indexOf(v)?.let { notifyItemChanged(it, PAYLOAD_STATE) }
        }

    fun indexOf(id: String?): Int? =
        if (id == null) null else items.indexOfFirst { it.id == id }.takeIf { it >= 0 }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.catName)
        val count: TextView = v.findViewById(R.id.catCount)
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_category, parent, false)
        val h = VH(v)
        v.setOnClickListener {
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClicked(items[pos])
        }
        v.setOnFocusChangeListener { _, hasFocus ->
            val pos = h.bindingAdapterPosition
            if (hasFocus && pos != RecyclerView.NO_POSITION) onFocused(items[pos])
        }
        return h
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val c = items[position]
        h.name.text = c.name
        h.count.text = c.count.toString()
        h.itemView.isActivated = c.id == selectedId
    }

    override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
        onBindViewHolder(h, position)
    }
}

class ChannelAdapter(
    private val onFocused: (Channel) -> Unit,
    private val onClicked: (Channel) -> Unit,
    private val onLongClicked: (Channel) -> Unit,
    private val nowTitle: (Channel) -> String?
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    var items: List<Channel> = emptyList()
        set(v) {
            field = v
            notifyDataSetChanged()
        }

    var favorites: Set<String> = emptySet()

    var playingId: String? = null
        set(v) {
            val old = field
            field = v
            indexOf(old)?.let { notifyItemChanged(it, PAYLOAD_STATE) }
            indexOf(v)?.let { notifyItemChanged(it, PAYLOAD_STATE) }
        }

    fun indexOf(id: String?): Int? =
        if (id == null) null else items.indexOfFirst { it.id == id }.takeIf { it >= 0 }

    fun refreshChannel(id: String) {
        indexOf(id)?.let { notifyItemChanged(it, PAYLOAD_STATE) }
    }

    fun refreshAll() {
        if (items.isNotEmpty()) notifyItemRangeChanged(0, items.size, PAYLOAD_STATE)
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val num: TextView = v.findViewById(R.id.chNum)
        val logo: ImageView = v.findViewById(R.id.chLogo)
        val name: TextView = v.findViewById(R.id.chName)
        val now: TextView = v.findViewById(R.id.chNow)
        val fav: TextView = v.findViewById(R.id.chFav)
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        val h = VH(v)
        v.setOnClickListener {
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClicked(items[pos])
        }
        v.setOnLongClickListener {
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onLongClicked(items[pos])
            true
        }
        v.setOnFocusChangeListener { _, hasFocus ->
            val pos = h.bindingAdapterPosition
            if (hasFocus && pos != RecyclerView.NO_POSITION) onFocused(items[pos])
        }
        return h
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val ch = items[position]
        if (ch.logo != null) {
            Glide.with(h.logo).load(ch.logo)
                .placeholder(R.drawable.ic_tv)
                .error(R.drawable.ic_tv)
                .fitCenter()
                .into(h.logo)
        } else {
            Glide.with(h.logo).clear(h.logo)
            h.logo.setImageResource(R.drawable.ic_tv)
        }
        bindState(h, ch)
    }

    override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isEmpty()) onBindViewHolder(h, position) else bindState(h, items[position])
    }

    private fun bindState(h: VH, ch: Channel) {
        h.num.text = ch.num.toString()
        h.name.text = ch.name
        val now = nowTitle(ch)
        h.now.text = now ?: ""
        h.now.visibility = if (now.isNullOrBlank()) View.GONE else View.VISIBLE
        h.fav.visibility = if (ch.id in favorites) View.VISIBLE else View.GONE
        h.itemView.isActivated = ch.id == playingId
    }
}
