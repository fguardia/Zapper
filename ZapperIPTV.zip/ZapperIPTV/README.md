# PillaloTv — TiviMate-style player for Android TV

A free, ad-free live TV player for Android TV / Google TV / Fire TV boxes.
Bring your own playlist: **Xtream Codes** login or an **M3U URL**.

## Features
- Xtream Codes login (server, username, password) or M3U / M3U8 playlist URL
- Several playlists saved; switch from the ⚙ button
- TiviMate-style browse screen: categories → channels → live preview + programme info
- Fullscreen player (ExoPlayer / Media3) for MPEG-TS and HLS, with auto-reconnect
- EPG: Xtream short EPG automatically, or any XMLTV guide (plain or .gz); `url-tvg` in the M3U header is picked up
- Favorites, channel search, number-key zapping, last-channel resume
- Movies & Series: poster grids, details page (plot, cast, rating), seasons/episodes,
  continue watching, resume position, auto-play next episode, audio/subtitle picker
- Custom user agent per playlist (default: VLC)

## Remote control
| Where | Key | Action |
|---|---|---|
| Fullscreen | ▲ / ▼ or CH+/CH− | Previous / next channel |
| Fullscreen | ◀ / ▶ / INFO | Show channel banner |
| Fullscreen | OK or BACK | Open channel list |
| Fullscreen | MENU | Add/remove favorite |
| Channel list | OK | Play in preview; OK again = fullscreen |
| Channel list | Hold OK or MENU | Add/remove favorite |
| Anywhere | 0–9 | Jump to channel number |
| Category list | BACK twice | Exit |

## Build the APK

### Option A — GitHub (free, no software to install)
1. Create a free account at github.com and make a new **private** repository.
2. On the repo page choose **Add file → Upload files**, drag in everything inside this folder
   (including the hidden `.github` folder), and commit.
3. Open the **Actions** tab. The *Build APK* workflow starts automatically (about 5 minutes).
4. When it shows a green check, open the run and download **ZapperIPTV-apk** under *Artifacts*.
   Unzip it to get `app-release.apk`.

> If the `.github` folder didn't upload (some computers hide it), create the file
> `.github/workflows/build-apk.yml` in the repo with **Add file → Create new file** and paste its contents.

### Option B — Android Studio
Open this folder in Android Studio → **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
The APK lands in `app/build/outputs/apk/`.

## Install on the TV
1. On the TV install **Downloader** (by AFTVnews) from the Play Store / Amazon Appstore.
2. Allow installs from unknown sources for Downloader (Settings → Apps → Security / Device preferences).
3. Put the APK somewhere with a direct link (Google Drive direct link, Dropbox, your own server)
   and open that link in Downloader, **or** use the *Send Files to TV* app, **or** copy it with a USB stick.
4. Open **PillaloTv** from the apps row and add your playlist.

## Notes
- Movies/series entries in M3U playlists are skipped; the app is focused on live TV.
- Requires Android 5.0+.
